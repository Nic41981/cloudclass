-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: cloudclass
-- ------------------------------------------------------
-- Server version	5.7.25-0ubuntu0.16.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chapter`
--

DROP TABLE IF EXISTS `chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chapter` (
  `id` varchar(35) NOT NULL COMMENT '章节ID',
  `course` varchar(35) NOT NULL COMMENT '课程ID',
  `num` int(11) NOT NULL COMMENT '章节序号',
  `name` varchar(255) NOT NULL COMMENT '章节名',
  `video` varchar(35) DEFAULT NULL COMMENT '视频文件ID',
  `info` text NOT NULL COMMENT '章节简介',
  `chapterExam` varchar(35) DEFAULT NULL COMMENT '章节测试ID',
  `createTime` datetime NOT NULL COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter`
--

LOCK TABLES `chapter` WRITE;
/*!40000 ALTER TABLE `chapter` DISABLE KEYS */;
INSERT INTO `chapter` VALUES ('f42cdf8c18a545cbae78a13b4b9a5ef1','4000847533e74509bba9015e2282a97b',1,'视频上传测试',NULL,'视频上传测试',NULL,'2019-07-02 14:12:05'),('169d750e3b214365be77a262237cfa6d','13b13349b3f045429d83eff15b8ef4b5',1,'22222',NULL,'0',NULL,'2019-07-11 21:34:52');
/*!40000 ALTER TABLE `chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter_exam`
--

DROP TABLE IF EXISTS `chapter_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chapter_exam` (
  `id` varchar(35) NOT NULL COMMENT '测试ID',
  `name` varchar(255) NOT NULL COMMENT '测试名',
  `createTime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter_exam`
--

LOCK TABLES `chapter_exam` WRITE;
/*!40000 ALTER TABLE `chapter_exam` DISABLE KEYS */;
/*!40000 ALTER TABLE `chapter_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` varchar(35) NOT NULL COMMENT '课程ID',
  `name` varchar(255) NOT NULL COMMENT '课程名',
  `image` varchar(255) DEFAULT NULL COMMENT '课程图片ID',
  `createTime` datetime NOT NULL COMMENT '创建时间',
  `teacher` varchar(35) NOT NULL COMMENT '教师用户ID',
  `tag` text COMMENT '标签',
  `finalExam` varchar(35) DEFAULT NULL COMMENT '期末考试ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('4000847533e74509bba9015e2282a97b','图片上传测试','小程序开发实战','2019-07-02 14:10:19','d5e092f2f9d547dcb76bf3f27cbc41bd','web前端',NULL),('38a23d7a2aac4a9ebd7af1ed50789dbb','课程1','小程序开发实战','2019-07-08 06:46:13','a6de2bf05acb462f933671993595a9d8','web前端','e24da4d2cecc421abfd929691adbd205'),('5bca702b245b454ba5fa01473f66c595','课程2','小程序开发实战','2019-07-08 06:46:43','a6de2bf05acb462f933671993595a9d8','人工智能',NULL),('8fa797352ce94a57a2e1889cd30b83dd','1111',NULL,'2019-07-11 20:55:48','a6de2bf05acb462f933671993595a9d8','',NULL),('13b13349b3f045429d83eff15b8ef4b5','2222',NULL,'2019-07-11 21:20:50','a6de2bf05acb462f933671993595a9d8','',NULL);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` varchar(35) NOT NULL COMMENT '文件ID',
  `filePath` varchar(255) NOT NULL COMMENT '文件路径',
  `mappingPath` varchar(255) NOT NULL COMMENT '映射路径',
  `realName` varchar(255) NOT NULL COMMENT '文件名',
  `suffix` varchar(10) NOT NULL COMMENT '文件后缀名',
  `uploadTime` datetime NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES ('rotation1','/usr/cloudclass/files/image/rotation/','/files/image/rotation/','rotation_picture_1','jpg','2019-04-22 13:22:12'),('rotation2','/usr/cloudclass/files/image/rotation/','/files/image/rotation/','rotation_picture_2','jpg','2019-04-22 13:22:12'),('rotation3','/usr/cloudclass/files/image/rotation/','/files/image/rotation/','rotation_picture_3','jpg','2019-04-22 13:22:12');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exam`
--

DROP TABLE IF EXISTS `final_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `final_exam` (
  `id` varchar(35) NOT NULL COMMENT '考试ID',
  `name` varchar(255) NOT NULL COMMENT '考试名',
  `startTime` datetime NOT NULL COMMENT '开始时间',
  `stopTime` datetime NOT NULL COMMENT '结束时间',
  `createTime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exam`
--

LOCK TABLES `final_exam` WRITE;
/*!40000 ALTER TABLE `final_exam` DISABLE KEYS */;
INSERT INTO `final_exam` VALUES ('e24da4d2cecc421abfd929691adbd205','课程1','2019-07-12 00:00:00','2019-07-12 02:00:00','2019-07-11 16:14:29');
/*!40000 ALTER TABLE `final_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course` varchar(35) NOT NULL,
  `content` text NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'81f88387543743328b30d7b299f33c01','公告','2019-04-22 22:18:20');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam` varchar(35) NOT NULL COMMENT '考试ID',
  `type` varchar(20) NOT NULL COMMENT '类型',
  `question` text NOT NULL COMMENT '问题',
  `score` int(11) NOT NULL COMMENT '分值',
  `options` text COMMENT '选项',
  `answer` text NOT NULL COMMENT '答案',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (39,'e24da4d2cecc421abfd929691adbd205','choice','aefpaojfa',75,'a<>v<>d<>c','C'),(40,'e24da4d2cecc421abfd929691adbd205','judgement','dsafefa',25,NULL,'true');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rotation_picture`
--

DROP TABLE IF EXISTS `rotation_picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rotation_picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `image` varchar(35) NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rotation_picture`
--

LOCK TABLES `rotation_picture` WRITE;
/*!40000 ALTER TABLE `rotation_picture` DISABLE KEYS */;
INSERT INTO `rotation_picture` VALUES (1,'index','rotation1','2019-04-22 13:23:17'),(2,'index','rotation2','2019-04-22 13:23:17'),(3,'index','rotation3','2019-04-22 13:23:17');
/*!40000 ALTER TABLE `rotation_picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score`
--

DROP TABLE IF EXISTS `score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `study` int(11) NOT NULL COMMENT '用户ID',
  `exam` varchar(35) NOT NULL COMMENT '考试ID',
  `createTime` datetime NOT NULL COMMENT '创建时间',
  `score` int(11) NOT NULL COMMENT '得分',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score`
--

LOCK TABLES `score` WRITE;
/*!40000 ALTER TABLE `score` DISABLE KEYS */;
/*!40000 ALTER TABLE `score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `study`
--

DROP TABLE IF EXISTS `study`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `study` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '学习ID',
  `student` varchar(35) NOT NULL COMMENT '用户ID',
  `course` varchar(35) NOT NULL COMMENT '课程ID',
  `createTime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study`
--

LOCK TABLES `study` WRITE;
/*!40000 ALTER TABLE `study` DISABLE KEYS */;
INSERT INTO `study` VALUES (11,'a6de2bf05acb462f933671993595a9d8','4000847533e74509bba9015e2282a97b','2019-07-10 08:57:24'),(12,'16ca842a3d034ea69d69d60228536b66','4000847533e74509bba9015e2282a97b','2019-07-10 10:27:13'),(13,'16ca842a3d034ea69d69d60228536b66','38a23d7a2aac4a9ebd7af1ed50789dbb','2019-07-11 16:33:00');
/*!40000 ALTER TABLE `study` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` varchar(35) NOT NULL COMMENT '用户ID',
  `name` varchar(255) NOT NULL COMMENT '用户名',
  `password` varchar(60) NOT NULL COMMENT '密码',
  `createTime` datetime NOT NULL COMMENT '注册日期',
  `identity` int(11) NOT NULL COMMENT '身份(0-学生,1-教师)',
  `email` varchar(255) NOT NULL COMMENT '电子邮件',
  `taken` varchar(60) DEFAULT NULL COMMENT '自动登录凭证',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('0ad2785e33cc4ffabd00d9170aa0aba0','nic','$2a$10$t/6ahPESQcgylqXV/IL3BeDEXXqOlf1YZJ.ZsaxmqxFuhDM9L4TdO','2019-04-17 19:37:04',1,'783415836@qq.com','$2a$10$VhAIaS1gWKwQUBrBHlCpAOa2DiYX9nwfAR8mFz.7aFO9RMRLzV8tq'),('102c463031814f8c81cb14178395c363','15293636393','$2a$10$EKQOSeNTF8x.6KmvX8ol6.XmqL1czNcbDCdHkmHuqOscnJMQOLorK','2019-04-25 01:12:57',0,'111',NULL),('16ca842a3d034ea69d69d60228536b66','student','$2a$10$ABg4/AbYDr2IPgrPVuWsyeHpwRCfaQHdJeLgbMLMP6sn7sVXG8Gj2','2019-04-18 17:43:10',0,'test@qq.com','$2a$10$qTMR778RcLMfSfZr091U3.BLgQ/zMjZLT3fXSS9ijj4p8ekJhRVZ.'),('8cc6aecf6f2c478f8a1d0f144270fb1d','15621151521','$2a$10$QpTjpFN7xdhqm21M6bF.pOesRFW6s1qWDS58MST9JcCNI/V59Rm16','2019-05-29 15:47:45',0,'xyt123@163.com','$2a$10$s3I.JWUVEFvIAHuxrdRMBOoz24uT6/T9MnIQ8uDK6/ThSBQDIEoEi'),('a6de2bf05acb462f933671993595a9d8','teacher','$2a$10$ABg4/AbYDr2IPgrPVuWsyeHpwRCfaQHdJeLgbMLMP6sn7sVXG8Gj2','2019-04-18 13:45:03',1,'123456789','$2a$10$aj52YyfMIhPTiXZ90FEmBu/sFtuiQez.XFyUtDqukDnXKDXijHmh.'),('d5e092f2f9d547dcb76bf3f27cbc41bd','admin','$2a$10$AHJHkarNube9BNNwkNZQc.G1TJO8dFcNAauJ9K6FS/DlAtrpVrwyS','2019-05-29 08:50:13',1,'dy@qq.com','$2a$10$WQzJ36NUpL1UT/TemPaDsustSgqLm8LBSO2Hs/9enVqiUKdBNpr4y');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-09 22:52:13
